//! Certified randomized images, authenticated bundles and first-complete selection.
use super::{algebra, encoding, Error, Image, ImageProof, Result, ValidatedSetup};
use ark_bls12_381::{Bls12_381 as E, Fr, G1Affine, G1Projective as G1, G2Affine};
use ark_ec::{pairing::Pairing, AffineRepr, CurveGroup, PrimeGroup};
use ark_serialize::{CanonicalDeserialize, CanonicalSerialize, Valid};
use ark_std::{UniformRand, Zero};
use rand::{CryptoRng, RngCore};
use sha2::{Digest, Sha256};
use std::{collections::HashSet, sync::Arc};
use zeroize::Zeroize;

#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct CommitteePublic {
    pub id: u32,
    pub key: G1Affine,
}
pub struct CommitteeKey {
    id: u32,
    scalar: Fr,
    public: CommitteePublic,
}
impl Drop for CommitteeKey {
    fn drop(&mut self) {
        self.scalar.zeroize();
    }
}
impl CommitteeKey {
    pub fn generate<R: RngCore + CryptoRng>(id: u32, rng: &mut R) -> Result<Self> {
        if id == 0 {
            return Err(Error("invalid committee identity"));
        }
        let scalar = loop {
            let s = Fr::rand(rng);
            if !s.is_zero() {
                break s;
            }
        };
        let public = CommitteePublic {
            id,
            key: (G1::generator() * scalar).into_affine(),
        };
        Ok(Self { id, scalar, public })
    }
    pub fn public(&self) -> CommitteePublic {
        self.public.clone()
    }
    /// Authentication does not certify that the signed image proofs are valid.
    pub fn authenticate(
        &self,
        pp: &ValidatedSetup,
        schedule: &Schedule,
        bundle: &mut Bundle,
    ) -> Result<()> {
        if bundle.member != self.id || !schedule.header.committee.contains(&self.public) {
            return Err(Error("authentication identity mismatch"));
        }
        let h = encoding::hash_to_g2(
            &auth_message(pp, schedule, bundle),
            b"SDVRF_AUTH_BLS12381G2_XMD:SHA-256_SSWU_RO_V1",
        )?;
        bundle.signature = (h * self.scalar).into_affine();
        Ok(())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct Header {
    pub application: Vec<u8>,
    pub release_policy: Vec<u8>,
    pub deadline: u64,
    pub committee: Vec<CommitteePublic>,
}
#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct Schedule {
    pub header: Header,
    pub labels: Vec<Vec<u8>>,
}
impl Schedule {
    pub fn validate(&self) -> Result<()> {
        if self.header.application.is_empty()
            || self.labels.is_empty()
            || self.header.committee.is_empty()
        {
            return Err(Error("empty schedule or committee"));
        }
        let mut labels = HashSet::new();
        for x in &self.labels {
            if !labels.insert(x) {
                return Err(Error("duplicate scheduled label"));
            }
        }
        let mut ids = HashSet::new();
        for c in &self.header.committee {
            if c.id == 0 || c.key.is_zero() || c.check().is_err() || !ids.insert(c.id) {
                return Err(Error("invalid committee registration"));
            }
        }
        Ok(())
    }
}
#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct Contribution {
    pub image: Image,
    pub proof: ImageProof,
}
#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct Bundle {
    pub member: u32,
    pub entries: Vec<Contribution>,
    pub signature: G2Affine,
}
#[derive(Clone, Debug, PartialEq, Eq, CanonicalSerialize, CanonicalDeserialize)]
pub struct RecordData {
    pub setup_id: [u8; 32],
    pub schedule: Schedule,
    pub board: Vec<Bundle>,
    pub images: Vec<Image>,
}
pub(crate) struct InputContext {
    pub tag: [u8; 32],
    pub h: G2Affine,
    pub transcript: merlin::Transcript,
    pub output_prefix: Sha256,
}
pub struct ValidatedRecord {
    pub(crate) setup: Arc<ValidatedSetup>,
    pub(crate) public: RecordData,
    pub(crate) inputs: Vec<InputContext>,
    pub(crate) included: Vec<u32>,
}
fn contexts(pp: &ValidatedSetup, s: &Schedule) -> Result<Vec<InputContext>> {
    s.validate()?;
    let mut prefix = Vec::new();
    encoding::field(&mut prefix, b"profile", b"SDVRF-BLS12381-v1");
    encoding::field(&mut prefix, b"setup", pp.encoded());
    encoding::field(&mut prefix, b"schedule", &encoding::bytes(s));
    s.labels
        .iter()
        .map(|x| {
            let mut eta = prefix.clone();
            encoding::field(&mut eta, b"label", x);
            let tag = encoding::digest(b"SDVRF-INPUT-ID-v1", &eta);
            let h = encoding::hash_to_g2(&eta, b"SDVRF_GRP_BLS12381G2_XMD:SHA-256_SSWU_RO_V1")?;
            let mut transcript = merlin::Transcript::new(b"SDVRF-IMAGE-FS-v1");
            transcript.append_message(b"eta", &eta);
            let mut output_context = Vec::new();
            encoding::field(&mut output_context, b"domain", b"SDVRF-OUTPUT-v1");
            encoding::field(&mut output_context, b"eta", &eta);
            let mut output_prefix = Sha256::new();
            output_prefix.update(output_context);
            Ok(InputContext {
                tag,
                h,
                transcript,
                output_prefix,
            })
        })
        .collect()
}
fn auth_message(pp: &ValidatedSetup, s: &Schedule, b: &Bundle) -> Vec<u8> {
    let mut message = Vec::new();
    encoding::field(&mut message, b"setup", pp.encoded());
    encoding::field(&mut message, b"schedule", &encoding::bytes(s));
    encoding::field(&mut message, b"member", &b.member.to_le_bytes());
    encoding::field(&mut message, b"entries", &encoding::bytes(&b.entries));
    message
}
pub fn contribute<R: RngCore + CryptoRng>(
    pp: &ValidatedSetup,
    schedule: &Schedule,
    key: &CommitteeKey,
    rng: &mut R,
) -> Result<Bundle> {
    if !schedule.header.committee.contains(&key.public) {
        return Err(Error("undesignated contributor"));
    }
    let inputs = contexts(pp, schedule)?;
    let mut entries = Vec::with_capacity(inputs.len());
    for input in &inputs {
        let mut s = std::array::from_fn(|_| Fr::rand(rng));
        let mut nonce = std::array::from_fn(|_| Fr::rand(rng));
        let image = algebra::image(pp, input.h, &s);
        let commitment = algebra::image(pp, input.h, &nonce);
        let c = algebra::image_challenge(&input.transcript, key.id, &image, &commitment);
        let responses = std::array::from_fn(|i| nonce[i] + c * s[i]);
        s.zeroize();
        nonce.zeroize();
        entries.push(Contribution {
            image,
            proof: ImageProof {
                commitment,
                responses,
            },
        });
    }
    let mut bundle = Bundle {
        member: key.id,
        entries,
        signature: G2Affine::zero(),
    };
    key.authenticate(pp, schedule, &mut bundle)?;
    Ok(bundle)
}
fn construct(
    setup: Arc<ValidatedSetup>,
    schedule: Schedule,
    board: Vec<Bundle>,
) -> Result<ValidatedRecord> {
    let inputs = contexts(&setup, &schedule)?;
    let mut images = vec![Image::zero(); inputs.len()];
    let mut seen = HashSet::new();
    let mut included = Vec::new();
    for b in &board {
        if b.check().is_err() {
            return Err(Error("malformed board group element"));
        }
        let Some(member) = schedule.header.committee.iter().find(|m| m.id == b.member) else {
            continue;
        };
        let h = encoding::hash_to_g2(
            &auth_message(&setup, &schedule, b),
            b"SDVRF_AUTH_BLS12381G2_XMD:SHA-256_SSWU_RO_V1",
        )?;
        if E::pairing(member.key, h) != E::pairing(G1::generator(), b.signature) {
            continue;
        }
        // Unauthenticated entries cannot suppress a member's genuine submission.
        if b.entries.len() != inputs.len() || !seen.insert(b.member) {
            continue;
        }
        let valid = b.entries.iter().zip(&inputs).all(|(f, input)| {
            algebra::verify_image(
                &setup,
                input.h,
                &input.transcript,
                b.member,
                &f.image,
                &f.proof,
            )
        });
        if valid {
            included.push(b.member);
            for (i, c) in b.entries.iter().enumerate() {
                images[i].add(&c.image);
            }
        }
    }
    if included.is_empty() {
        return Err(Error("no accepted complete contribution"));
    }
    let public = RecordData {
        setup_id: setup.id(),
        schedule,
        board,
        images,
    };
    Ok(ValidatedRecord {
        setup,
        public,
        inputs,
        included,
    })
}
pub fn finalize_record(
    setup: Arc<ValidatedSetup>,
    schedule: Schedule,
    board: Vec<Bundle>,
) -> Result<ValidatedRecord> {
    construct(setup, schedule, board)
}
pub fn validate_record(setup: Arc<ValidatedSetup>, data: RecordData) -> Result<ValidatedRecord> {
    if data.setup_id != setup.id() {
        return Err(Error("record/setup mismatch"));
    }
    let record = construct(setup, data.schedule.clone(), data.board.clone())?;
    if record.public != data {
        return Err(Error("record differs from canonical board recomputation"));
    }
    Ok(record)
}
impl ValidatedRecord {
    pub fn data(&self) -> &RecordData {
        &self.public
    }
    pub fn setup(&self) -> &ValidatedSetup {
        &self.setup
    }
    pub fn included(&self) -> &[u32] {
        &self.included
    }
    pub fn input_count(&self) -> usize {
        self.inputs.len()
    }
    pub fn input_tag(&self, index: usize) -> Result<[u8; 32]> {
        Ok(self.input(index)?.tag)
    }
    pub fn hash_point(&self, index: usize) -> Result<G2Affine> {
        Ok(self.input(index)?.h)
    }
    pub(crate) fn input(&self, index: usize) -> Result<&InputContext> {
        self.inputs.get(index).ok_or(Error("unscheduled input"))
    }
}

/// Immutable public data for one (PP,D). Fixed-base tables can be shared by
/// contributors: they contain only public point multiples, never image coins.
pub struct PreparedBatch {
    setup: Arc<ValidatedSetup>,
    schedule: Schedule,
    inputs: Vec<InputContext>,
    bases: super::fixed::ImageBases,
    hashes: Vec<super::fixed::Fixed<ark_bls12_381::G2Projective>>,
}
impl PreparedBatch {
    pub fn new(setup: Arc<ValidatedSetup>, schedule: Schedule) -> Result<Self> {
        let inputs = contexts(&setup, &schedule)?;
        let bases = super::fixed::ImageBases::new(&setup);
        let hashes = inputs
            .iter()
            .map(|i| super::fixed::input_base(i.h))
            .collect();
        Ok(Self {
            setup,
            schedule,
            inputs,
            bases,
            hashes,
        })
    }
    pub fn contribute<R: RngCore + CryptoRng>(
        &self,
        key: &CommitteeKey,
        rng: &mut R,
    ) -> Result<Bundle> {
        if !self.schedule.header.committee.contains(&key.public) {
            return Err(Error("undesignated contributor"));
        }
        let mut entries = Vec::with_capacity(self.inputs.len());
        for (input, h) in self.inputs.iter().zip(&self.hashes) {
            let mut s = std::array::from_fn(|_| Fr::rand(rng));
            let mut nonce = std::array::from_fn(|_| Fr::rand(rng));
            let image = self.bases.image(h, &s);
            let commitment = self.bases.image(h, &nonce);
            let c = algebra::image_challenge(&input.transcript, key.id, &image, &commitment);
            let responses = std::array::from_fn(|i| nonce[i] + c * s[i]);
            s.zeroize();
            nonce.zeroize();
            entries.push(Contribution {
                image,
                proof: ImageProof {
                    commitment,
                    responses,
                },
            });
        }
        let mut bundle = Bundle {
            member: key.id,
            entries,
            signature: G2Affine::zero(),
        };
        key.authenticate(&self.setup, &self.schedule, &mut bundle)?;
        Ok(bundle)
    }
    fn check_bundle(&self, b: &Bundle) -> Result<(bool, bool)> {
        // One complete subgroup check covers both images, all proof commitments
        // and the signature. These checks are never omitted in the cached path.
        if b.check().is_err() {
            return Err(Error("malformed board group element"));
        }
        let Some(member) = self
            .schedule
            .header
            .committee
            .iter()
            .find(|m| m.id == b.member)
        else {
            return Ok((false, false));
        };
        let h = encoding::hash_to_g2(
            &auth_message(&self.setup, &self.schedule, b),
            b"SDVRF_AUTH_BLS12381G2_XMD:SHA-256_SSWU_RO_V1",
        )?;
        let authenticated = E::multi_pairing(
            [member.key, (-G1::generator()).into_affine()],
            [h, b.signature],
        )
        .is_zero();
        if !authenticated || b.entries.len() != self.inputs.len() {
            return Ok((authenticated, false));
        }
        let valid = b
            .entries
            .iter()
            .zip(&self.inputs)
            .zip(&self.hashes)
            .all(|((f, input), h)| {
                let c = algebra::image_challenge(
                    &input.transcript,
                    b.member,
                    &f.image,
                    &f.proof.commitment,
                );
                let lhs = self.bases.image(h, &f.proof.responses);
                (0..2).all(|i| {
                    lhs.g1[i] == (f.proof.commitment.g1[i] + f.image.g1[i] * c).into_affine()
                }) && (0..6).all(|i| {
                    lhs.g2[i] == (f.proof.commitment.g2[i] + f.image.g2[i] * c).into_affine()
                })
            });
        Ok((true, valid))
    }
    /// Proofs may be checked concurrently; first-complete selection always uses
    /// the supplied board order, including authenticated invalid first bundles.
    pub fn finalize(self, board: Vec<Bundle>, workers: usize) -> Result<ValidatedRecord> {
        if workers == 0 {
            return Err(Error("at least one verification worker required"));
        }
        let chunks = board.len().div_ceil(workers).max(1);
        let results = std::thread::scope(|scope| {
            let jobs: Vec<_> = board
                .chunks(chunks)
                .map(|chunk| {
                    let this = &self;
                    scope.spawn(move || {
                        chunk
                            .iter()
                            .map(|b| this.check_bundle(b))
                            .collect::<Vec<_>>()
                    })
                })
                .collect();
            jobs.into_iter()
                .flat_map(|job| job.join().expect("verification worker panicked"))
                .collect::<Vec<_>>()
        });
        use ark_bls12_381::G2Projective as G2;
        let mut g1 = vec![[G1::zero(); 2]; self.inputs.len()];
        let mut g2 = vec![[G2::zero(); 6]; self.inputs.len()];
        let mut seen = HashSet::new();
        let mut included = Vec::new();
        for (b, result) in board.iter().zip(results) {
            let (authenticated, valid) = result?;
            if !authenticated || b.entries.len() != self.inputs.len() || !seen.insert(b.member) {
                continue;
            }
            if valid {
                included.push(b.member);
                for (i, c) in b.entries.iter().enumerate() {
                    for (sum, point) in g1[i].iter_mut().zip(c.image.g1) {
                        *sum += point;
                    }
                    for (sum, point) in g2[i].iter_mut().zip(c.image.g2) {
                        *sum += point;
                    }
                }
            }
        }
        if included.is_empty() {
            return Err(Error("no accepted complete contribution"));
        }
        let a = G1::normalize_batch(&g1.into_iter().flatten().collect::<Vec<_>>());
        let b = G2::normalize_batch(&g2.into_iter().flatten().collect::<Vec<_>>());
        let images = (0..self.inputs.len())
            .map(|i| Image {
                g1: [a[2 * i], a[2 * i + 1]],
                g2: std::array::from_fn(|k| b[6 * i + k]),
            })
            .collect();
        Ok(ValidatedRecord {
            public: RecordData {
                setup_id: self.setup.id(),
                schedule: self.schedule,
                board,
                images,
            },
            setup: self.setup,
            inputs: self.inputs,
            included,
        })
    }
}
