//! Public fixed-base tables; no secret scalars or trapdoor encodings are stored.
use super::{Image, ValidatedSetup};
use ark_bls12_381::{Fr, G1Projective as G1, G2Affine, G2Projective as G2};
use ark_ec::{
    scalar_mul::{BatchMulPreprocessing, ScalarMul},
    AffineRepr, CurveGroup,
};
use ark_ff::{BigInteger, PrimeField};

pub(crate) struct Fixed<G: ScalarMul<ScalarField = Fr>>(BatchMulPreprocessing<G>);
impl<G: ScalarMul<ScalarField = Fr>> Fixed<G> {
    pub fn new(base: G) -> Self {
        Self(BatchMulPreprocessing::new(base, 128))
    }
    pub fn mul(&self, s: &Fr) -> G {
        let bits = s.into_bigint().to_bits_le();
        let table = &self.0;
        let mut result = G::zero();
        for (outer, row) in table.table.iter().enumerate() {
            let mut inner = 0;
            for i in 0..table.window {
                let bit = outer * table.window + i;
                if bit < bits.len() && bits[bit] {
                    inner |= 1 << i;
                }
            }
            result += &row[inner];
        }
        result
    }
}
pub(crate) struct ImageBases {
    c: Fixed<G1>,
    shift: Fixed<G1>,
    g: Fixed<G1>,
    q: Fixed<G2>,
    z: Fixed<G2>,
    tau: Fixed<G2>,
    minus: Fixed<G2>,
}
impl ImageBases {
    pub fn new(pp: &ValidatedSetup) -> Self {
        let d = pp.data();
        let c = &d.crs;
        let q = c.g2[0];
        Self {
            c: Fixed::new(d.aggregate.into_group()),
            shift: Fixed::new(c.g1[pp.threshold() + 1].into_group()),
            g: Fixed::new(c.g1[0].into_group()),
            q: Fixed::new(q.into_group()),
            z: Fixed::new(c.g2[pp.slots()] - q),
            tau: Fixed::new(c.g2[1].into_group()),
            minus: Fixed::new(c.g2[1] - q),
        }
    }
    pub fn image(&self, h: &Fixed<G2>, s: &[Fr; 5]) -> Image {
        let a = G1::normalize_batch(&[
            self.c.mul(&s[0]) + self.shift.mul(&s[3]) + self.g.mul(&s[4]),
            self.g.mul(&s[2]),
        ]);
        let b = G2::normalize_batch(&[
            self.q.mul(&s[0]) + h.mul(&s[2]),
            self.z.mul(&s[0]),
            self.tau.mul(&(s[0] + s[1])),
            self.q.mul(&s[1]),
            self.q.mul(&s[3]),
            self.minus.mul(&s[4]),
        ]);
        Image {
            g1: a.try_into().unwrap(),
            g2: b.try_into().unwrap(),
        }
    }
}
pub(crate) fn input_base(h: G2Affine) -> Fixed<G2> {
    Fixed::new(h.into_group())
}
